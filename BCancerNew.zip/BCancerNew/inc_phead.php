
<?php include "inc_head.php";?>
<div class="page-heading-one">
						<h2>Welcome</h2>
						<p class="bg-color"><?php echo $userData['name']; ?></p>
					</div>
<div class="nav-tabs-three">
						<!-- Design Three Sidebar -->
						<div class="nav-tabs-three-sidebar">
							<ul class="nav">
								<li><a href="#bc" data-toggle="tab"><i class="fa fa-ambulance"></i> Basic Check
								<!-- <li><a href="#profile-3" data-toggle="tab"><i class="fa fa-medkit"></i> Profile</a></li> -->
								<li><a href="#mammogram" data-toggle="tab"><i class="fa fa-bell"></i> Mammogram Test</a></li>
								<li><a href="#bio" data-toggle="tab"><i class="fa fa-bell"></i> Biospy Test</a></li>
								
								<li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
							</ul>
						</div>
						<!-- Design Three Content -->
						<div class="nav-tabs-three-content">
							<div class="tab-content">