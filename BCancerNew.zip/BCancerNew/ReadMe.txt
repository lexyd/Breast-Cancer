1. Download/Get XAMMP server latest version(From version 5.6.12 and above).
2. Install it.
3. Open It and try to start 'Apache' and 'MySQL' server.
4. After starting it successfully, type the following on your web browser (preferably chrome):
    "localhost/phpmyadmin"
5. it will load the database interface then 
6. click on create new database
7. name the database the name of the SQL file you saw in the extracted folder
8. After that you click on the import bar and import that SQL file into the database
9. your database is ready
10. Finally copy the software folder into this directory 'C:\xamppp\htdocs'.
11. now load the software on your web browser by typing the followng on a new tab 'localhost/software_folder_name'

Users(doctor and patient)
email: user@gmail.com
password: user

admin
email: admin@gmail.com
password: admin

From Atueyi Chike
08101654755
Software Developer