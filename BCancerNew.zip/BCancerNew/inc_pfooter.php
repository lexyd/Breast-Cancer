
								

							</div>
						</div>
						<!-- Clearfix -->
						<div class="clearfix"></div>
					</div>

					<?php include "inc_footer.php";?>