<?php include "inc_head.php";?>



					<div id="bs-carousel-1" class="carousel slide" data-ride="carousel" data-interval="5000" data-pause      ="hover" data-wrap="true">
						<!-- Bootstrap indicators. If you don't need indicators, remove the below section -->
						<!-- <ol class="carousel-indicators">
							<li data-target="#bs-carousel-1" data-slide-to="0" class="active"></li>
							<li data-target="#bs-carousel-1" data-slide-to="1"></li>
							<li data-target="#bs-carousel-1" data-slide-to="2"></li>
							<li data-target="#bs-carousel-1" data-slide-to="3"></li>
						</ol> -->
						<!-- Slides. You can also add captions -->
						<div class="carousel-inner">
							<!-- Item, First item should have extra class "active" -->
							<div class="item active">
								<!-- Image -->
								<img src="img2/c4.jpg" alt="">
								<!-- Right big -->
								
							</div>
						</div>
						<!-- Carousel controls (arrows). If you don't need controls, remove the below section -->
						<!-- <a class="left carousel-control" href="#bs-carousel-1" role="button" data-slide="prev">
							<span class="fa fa-chevron-left"></span>
						</a>
						<a class="right carousel-control" href="#bs-carousel-1" role="button" data-slide="next">
							<span class="fa fa-chevron-right"></span>
						</a> -->
					</div>
					
					<div class="modal fade modal-load" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					        <h4 class="modal-title" id="myModalLabel">Breast Cancer Checker. Built By:</h4>
					      </div>
					      <div class="modal-body">
					       <p class="text-center">Inyene Ikot | 2012/2902</p>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn g-btn btn-default" data-dismiss="modal">Close</button>
					        
					      </div>
					    </div>
					  </div>
					</div>
<?php include "inc_footer.php";?>