<?php
if (isset($_SESSION["uid"])) {
	$trial = true;
} else {
	$trial = false;
}
?>


<!DOCTYPE html>
<html>

<head>
		<meta charset="utf-8">
		<title>Breast Cancer Check</title> <!-- DYNAMIC TITLE -->
		<!-- Description, Keywords and Author -->
		<meta name="description" content="Your description">
		<meta name="keywords" content="Your,Keywords">
		<meta name="author" content="ResponsiveWebInc">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Styles -->
		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!-- Font awesome CSS -->
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<!-- Magnific Popup -->
		<link href="css/magnific-popup.css" rel="stylesheet">
		<!-- Owl carousel -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		
		<!-- CSS for this page -->
		<!-- Medical CSS -->
		<link href="css/styles/medical.css" rel="stylesheet">
		
		<!-- Base style -->
		<link href="css/styles/style.css" rel="stylesheet">
		<!-- Skin CSS -->
		<link href="css/styles/skin-lblue.css" rel="stylesheet" id="color_theme">
		
		<!-- Custom CSS. Type your CSS code in custom.css file -->
		<link href="css/custom.css" rel="stylesheet">
		<script src="js/jquery.js"></script>
		<script src="js/custom.js"></script>		
		<!-- Favicon -->
		<link rel="shortcut icon" href="#">

<script type="text/javascript" src="chart/fusioncharts.js"></script>

<!-- 
<script type="text/javascript">

FusionCharts.ready(function () {
    var revenueChart = new FusionCharts({
        type: 'doughnut2d',
        renderAt: 'chart-container',
        width: '450',
        height: '450',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Split of Revenue by Product Categories",
                "subCaption": "Last year",
                "numberPrefix": "$",
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",
                "defaultCenterLabel": "Total revenue: $64.08K",
                "centerLabel": "Revenue from $label: $value",
                "centerLabelBold": "1",
                "showTooltip": "0",
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0"
            },
            "data": [
                {
                    "label": "Food",
                    "value": "28504"
                }, 
                {
                    "label": "Apparels",
                    "value": "14633"
                }, 
                {
                    "label": "Electronics",
                    "value": "10507"
                }, 
                {
                    "label": "Household",
                    "value": "4910"
                }
            ]
        }
    }).render();
});
</script> -->


	</head>
	
	<!-- Add class "boxed" along with body for boxed layout. -->
	<!-- Add "pattern-x" (1 to 5) for background patterns. -->
	<!-- Add "img-x" (1 to 5) for background images. -->
	<body>
	
		<!-- Outer Starts -->
		<div class="outer">
			
			<!-- Top bar starts -->
			<!--  -->
			
			<!-- Top bar ends -->
			
			<!-- Header two Starts -->
			<div class="header-2">
			
				<!-- Container -->
				<div class="container">
					<div class="row">
						<div class="col-md-2">
							<!-- Logo section -->
							<div class="logo">
								<h1><a href="#"><i class="fa fa-laptop"></i>BCheck</a></h1>
							</div>
						</div>
						<div class="col-md-9">
						
							<!-- Navigation starts.  -->
							<?php
							if (!$trial) {
								echo '<div class="navy navbar-right">			
								<ul>
									<li><a href="index.php">Home</a></li>
									
									<li><a href="login.php">Login</a></li>
									
									<li></li>
								</ul>
							</div>';
							}
							?>							
							<!-- Navigation ends -->
							
						</div>						
					</div>
				</div>
			</div>
	
			<!-- Header two ends -->
			
			<div class="medical-home">
			
				<div class="container">