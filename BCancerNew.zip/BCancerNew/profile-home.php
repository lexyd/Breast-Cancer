<?php include "core/handle.php";?>

<?php
// 

if(isset($_SESSION['uid']))
{
	$user_id = $_SESSION['uid'];
	$userData = getUserData($con,$user_id, 'tbl_doc');
}
	
else
	header("Location: index.php");


?>




<link href="css/smart-forms.css" rel="stylesheet">
<?php include "inc_phead.php";?>






<input type="hidden" name="glbuid" id="glbuid" value="<?php echo $userData['id'] ?>"> 
<!-- DIAGNOSIS CHECK TAB-->
<div class="tab-pane  fade in active" id="bc">


			<div style="display: none;" id="diagMsg" class="jumbotron">

			</div>


			<h4>Please tick the appropriate signs & symptoms</h4>
			<br>
			<br>
			<div class="smart-forms">
			  <form class="diagnose" id="form-elements">
			  	  <div class="row">

			  	    <!-- checkboxes for malaria -->
					  <div class="col-md-12 col-sm-6">
							<div class="row">
								 <div class="option-group field">
								  <div class="col-sm-6">
									  <label class="option">
											<input type="checkbox" value="swelling" class="s1" >
											<span class="checkbox"></span> Swelling in a part of the breast               
									  </label>
									</div>

									<div class="col-sm-6">																							
									  <label class="option">
											<input type="checkbox" class="s1" value="skin-irritation" name="checkbox1">
											<span class="checkbox"></span> Skin irritation                   
									  </label>
									</div>
																 
								 </div><!-- end .option-group section -->
							</div>	

							<div class="row">
								 <div class="option-group field">
								 
								 <div class="col-sm-6">
									  <label class="option">
											<input type="checkbox" name="checkbox1" value="profuse-sweating" class="s1" >
											<span class="checkbox"></span> Breast Pain               
									  </label>
								</div>
									<div class="col-sm-6">										
									  <label class="option">
											<input type="checkbox" class="s1" value="nipple-pain" name="checkbox1">
											<span class="checkbox"></span> Nipple Pain                   
									  </label>
										</div>						 
								 </div><!-- end .option-group section -->
							</div>

							<div class="row">
								 <div class="option-group field">
								 <div class="col-sm-6">
									  <label class="option">
											<input type="checkbox" name="checkbox1" value="nipple-retraction" class="s1" >
											<span class="checkbox"></span> Nipple Retraction (turning inward)               
									  </label>
									  </div>
									  <div class="col-sm-6">
																			
									  <label class="option">
											<input type="checkbox" class="s1" value="redness-of-nipple" name="checkbox1">
											<span class="checkbox"></span> Redness of Nipple                  
									  </label>
									  </div>
																 
								 </div><!-- end .option-group section -->
							</div>

							<div class="row">
								 <div class="option-group field">
								 <div class="col-sm-6">
									  <label class="option">
											<input type="checkbox" name="checkbox1" value="scaliness-of-nipple" class="s1" >
											<span class="checkbox"></span> Scaliness of Nipple               
									  </label>
									  </div>
									  <div class="col-sm-6">
																			
									  <label class="option">
											<input type="checkbox" class="s1" value="nipple-discharge" name="checkbox1">
											<span class="checkbox"></span> Nipple Discharge (other than breast milk)                   
									  </label>
									  </div>
																 
								 </div><!-- end .option-group section -->
							</div>
							<br>
							<br>
							<div class="row">
								<div class="col-md-3">
									<div class="form-group">
								    <label for="exampleInputEmail1">Patient's Name</label>
								    <input type="text" name="pname"   class="form-control" required id="pname" placeholder="Patients Name">
								  </div>
								</div>
							</div>
							<div class="row">
								<blockquote>
								  <p>Although these symptoms can be caused by things other than breat cancer, if you have them, they should be reported to a health care providerso that he or she can find the cause.</p>
								</blockquote>
							</div>
			          </div>
			         																  
			  	  </div>
			  	  <div class="row">
					  <div class="col-md-4 col-sm-6 col-md-offset-4">
					  	 <button type="" id="check" class="g-btn ">Check Diagnosis</button>
					  </div>
					</div>
			  </form>
			</div>

				<!-- Message of diagnosis display section -->				
</div>

<!-- HISTORY TAB -->
<!-- <div class="tab-pane fade" id="history">

	<h4>Diagnosis History</h4>

	<?php ?>


	<table class="table table-condensed">
	  <th>Diagnosis </th>
	  <th class="text-center">Symtomps</th>
	  <th>Date</th>
	  <tbody>
	  <?php while($rowU = mysqli_fetch_assoc($userhist)) {
	  $symz1 = explode("|", $rowU['syms']);
	  $symz2 = implode(",", $symz1)
	  ?>
	  	<tr>
	  		<td class="text-center"><?php echo $rowU['stype'] ?></td>
	  		<td class="text-center"><?php echo $symz2  ?></td>
	  		<td><?php echo $rowU['prs_date'] ?></td>
	  	</tr>
	  	<?php   } ?>
	  </tbody>
	</table>
</div> -->

<!-- SEND MESSAGE -->
<div class="tab-pane fade" id="mammogram">
	
		<div class="row">
			<form id="msg4m" >
				<div class="row">
				   <div class="col-md-3">
						<div class="form-group">
					    <label for="exampleInputEmail1">Number of White Spots</label>
					    <input type="text" name="pname"  class="form-control" required id="pname" placeholder="Number of White Spots">
					  </div>
					</div>

					<div class="col-md-3">
						<div class="form-group">
					    <label for="exampleInputEmail1">Number of Lumps</label>
					    <input type="text" name="pname"  class="form-control" required id="pname" placeholder="Number of Lumps">
					  </div>
					</div>

					<div class="col-md-3">
						<div class="form-group">
					    <label for="exampleInputEmail1">Patient Name</label>
					    <input type="text" name="pname"  class="form-control" required id="name2" placeholder="Patient Name">
					  </div>
					</div>

					<div class="form-group">
						<label for="user" class="col-sm-3 control-label">Birad Score </label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="score" name="utype">
								 <option value="">Select Birad Score</option>
								 <option value="0">0</option>
								 <option value="1">1</option>
								 <option value="2">2</option>
								 <option value="3">3</option>
								 <option value="4">4</option>
								 <option value="5">5</option>
								 <option value="6">6</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>


					<div class="form-group">
					<label for="Submit"></label>
					<div class="col-md-6 col-md-offset-5"><button id="smsg" class="g-btn">Submit</button></div>
				  </div>
				  </div>
			  </form>
		</div>
</div>

<div class="tab-pane fade" id="bio">
    <div class="row">
			<form id="bio" >
			<div class="col-md-6">
				<div class="form-group">
						<label for="user" class="col-sm-3 control-label">Type of Tumor</label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="tot" required name="tot">
								 <option value="">Type of Tumor</option>
								 <option value="5">Soft Tumor</option>
								 <option value="10">Hard Tumor</option>
								 <option value="0">No Tumor</option>
								 <option value="5">Average Tumor</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>
					</div>
					
					<div class="col-md-6">
					<div class="form-group">
						<label for="user" class="col-sm-3 control-label">Size of Tumor</label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="sot" required name="sot">
								 <option value="">Size of Tumor</option>
								 <option value="5">Small</option>
								 <option value="10">Average</option>
								 <option value="30">Big</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>
					</div>

					<div class="col-md-6">
					<div class="form-group">
						<label for="user" class="col-sm-3 control-label">Number of Tumor</label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="not" required name="not">
								 <option value="">Number of Tumor</option>
								 <option value="5">0</option>
								 <option value="10">1 - 2</option>
								 <option value="30">3 - Above</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>
					</div>


					<div class="col-md-6">
					<div class="form-group">
						<label for="user" class="col-sm-3 control-label">Cancer Cells</label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="cc" required name="cc">
								 <option value="">Cancer Cells</option>
								 <option value="30">Yes</option>
								 <option value="0">No</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>
					</div>



					<div class="col-md-6">
						<div class="form-group">
					    <label for="exampleInputEmail1">Patient Name</label>
					    <input type="text" name="pname"  class="form-control" required id="name3" placeholder="Patient Name">
					  </div>
					</div>
				
					<div class="form-group">
					<label for="Submit"></label>
					<div class="col-md-6 col-md-offset-5"><button id="biocheck" class="g-btn">Check</button></div>
				  </div>

			</form>
	</div>
</div>

<div class="tab-pane fade" id="messagehist">

   <table class="table table-condensed">
   <th>SN</th>
   	<th class="text-center">Message</th>
   	<th class="text-center">Reply</th>
<?php $i=1; while ($rowMH = mysqli_fetch_assoc($sqlmsghist)) { ?>
   	<tr>
   		<td><?php echo $i ;?></td>
   		<td class="text-center"><?php echo $rowMH['msg'];?></td>
   		<td class="text-center"><?php echo $rowMH['reply'];?></td>
   	</tr>
<?php $i++; } ?>
   </table>
	         
</div>

<!-- PREVENTIVE MEASURES -->
<div class="tab-pane fade" id="message">
</div>

<?php include "inc_pfooter.php";?>

