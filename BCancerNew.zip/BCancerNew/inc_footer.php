
				</div>
			
			</div>
			



			<footer>
				<!-- Container -->
				<div class="container">
					<!-- Footer Content -->
						<!-- Paragraph -->
						<p class="text-center"> Copyright 2017</p>
						<div class="clearfix"></div>
				</div>
			</footer>
			
			<!-- Footer Ends -->
		
		</div>
		
		<!-- Outer Ends -->		
		
		<!-- Scroll to top -->
		<span class="totop"><a href="#"><i class="fa fa-angle-up bg-color"></i></a></span>
		
		<!-- Javascript files -->
		<!-- jQuery -->
		
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Placeholders JS -->
		<script src="js/placeholders.js"></script>
		<!-- Magnific Popup -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Owl carousel -->
		<script src="js/owl.carousel.min.js"></script>
		<!-- Respond JS for IE8 -->
		<script src="js/respond.min.js"></script>
		<!-- HTML5 Support for IE -->
		<script src="js/html5shiv.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>

		<script src="js/template.js"></script>
		
		<script src="style-switcher/style-switcher.js"></script>
		
	</body>	
</html>