
<?php include "inc_head.php";?>
<div class="page-heading-one">
						<h2>Welcome</h2>
						<p class="bg-color"><?php echo $userData['name']; ?></p>
					</div>
<div class="nav-tabs-three">
						<!-- Design Three Sidebar -->
						<div class="nav-tabs-three-sidebar">
							<ul class="nav">
								<li><a href="#home-3" data-toggle="tab"><i class="fa fa-ambulance"></i>  Doctors</a></li>
								<li><a href="#admins" data-toggle="tab"><i class="fa fa-bell"></i> Administrators</a></li>
								<li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
							</ul>
						</div>
						<!-- Design Three Content -->
						<div class="nav-tabs-three-content">
							<div class="tab-content">