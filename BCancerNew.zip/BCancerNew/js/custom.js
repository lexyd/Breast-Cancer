/* Your JS codes here */
$(document).ready(function () {


	//alert('WORKS');
	$(".modal-load").modal('show');
   

	$('.diagnose').submit(function(e) {
		e.preventDefault();

		var pname = $("#pname").val();
		//declare arrays of different sickness types
		var stage1 = [];
		

		//fill up arrays based on the class of a particular check button
		$('.s1').each(function() {
				if($(this).is(":checked")){
					stage1.push($(this).val());
				}
			});

		if(stage1.length < 1 )
		{
			alert("More Symptoms are needed for proper diagnosis");
		}else
		{
			//$("#diagMsg").show().fadeIn(3000);
			$.ajax({

				url: 'core/process.php',
				method: 'POST',
				data  : {
					diagnose: 1,
					pname:pname,
					s1: stage1
				},
				success : function(data){
					if(data == 1){
						window.location = 'test.php';
					}

				}

			})
		}
	});


	$("#msg4m").submit(function (e) {
		e.preventDefault();
		var name2 = $("#name2").val();
		var test  = 'mammogram';
		var score = $("#score").val();
		//alert(score);

		$.ajax({

				url: 'core/pro2.php',
				method: 'POST',
				data  : {
					diagnose: 1,
					name:name2,
					score:score,
					test:test
				},
				success : function(data){

					// alert(data);

					if(data == 1){
						window.location = 'mamotest.php';
					}

				}

			})
     })

	$("#bio").submit(function (e) {
		e.preventDefault();

		var tot = $("#tot").val();
		var sot = $("#sot").val();
		var not = $("#not").val();
		var cc = $("#cc").val();
		var patname = $("#name3").val();

		$.ajax({

				url: 'core/pro3.php',
				method: 'POST',
				data  : {
					diagnose: 1,
					tot:tot,
					sot:sot,
					not:not,
					name:patname,
					cc:cc
				},
				success : function(data){

					if(data == 1){
						window.location = 'biospy.php';
						//alert(data);
					}

				}

			})




	});



//other js files to be used when needed

// $(".jumbotron").on("click","#endMsg",function () {
// 	$("#diagMsg").hide().fadeOut(4000);
// })



// $("#message-body").on("click",".reply",function() {

// 	    var msgId = $(this).data('msgd');
// 	    $(".ReplyForm").show();
// 	    $("#messageId").val(msgId);

// 	    //alert(msgId);
	   
// })

// $("#repmsg").click(function(e) {
// 	e.preventDefault();
// 	var id = $("#messageId").val();
// 	var msg = $("#repmsgcontent").val();
// 	//alert(id);
// 	 $.ajax({
// 	    	url : 'core/reply.php',
// 	    	method: 'POST',
// 	    	data : {msgId: id, message: msg},
// 	    	success : function (data){
// 	    		if(data == 1)
// 	    		{
// 	    			alert("Reply Sent");
// 	    			$("#repform1").trigger('reset');
// 	    			$(".ReplyForm").hide();
// 	    		}else{
// 	    			alert(data);
// 	    		}
	    		

// 	    	}
// 	    })
// })

// //send message
// $("#smsg").click(function(e) {
// 	e.preventDefault();
// 	var message = $("#msgDoc").val();
// 	//alert('works');
// 	$.ajax({
// 		url : "core/message.php",
// 		method: 'POST',
// 		data  : {
// 					msg : 1,
// 					message : message,
// 					id      : userId
// 				},
// 		success : function (data){
// 			alert(data);
// 			$("#msg4m").trigger('reset');
// 		}


// 	})
// })


// //REGISTER USER
// $('#register-form').submit(function(e) {
// 	e.preventDefault();
// 	//alert("works");
// 	$.ajax({

// 		url: "core/register.php",
// 		method: "POST",
// 		data  : $("#register-form").serialize(),
// 		// beforeSend: function (){
// 		// 	$("#register").html("Processing...<i class='fa fa-spinner spin'></i>");
// 		// },
// 		success: function(data){
// 			if(data == 1)
// 			{
// 				$("#register").html("Thanks for Registering <i class='fa fa-thumbs-up fa-rotate-45'></i>");
// 				$("#profile").html("Go to my Profile <i class='fa fa-user'></i>");
// 				$("#profile").attr({href: 'profile-home.php'});
// 				$("#form-sect").hide();
// 				$("#register").hide();
				
// 			}else
// 			{
// 				$("#regmsg").html(data);
// 			}

			
// 		}

// 	})
// })

$("#loginform").submit(function(e) {
	e.preventDefault();
	var email  =  $("#email").val();
	var pass  =  $("#pass").val();
	var utype  =  $("#utype").val();
	//alert("works");

	$.ajax({
		url : "core/login.php",
		method : "POST",
		data  :{
			log : 1,
			email: email,
			pass: pass,
			utype: utype
		},

		success: function (data){
			//alert(data);
			if(data == 1)
			{
				window.location = 'admin-home.php';
			}else if(data == 2)
			{
				window.location = 'profile-home.php';
			}else if(data == 3)
			{
				window.location = 'profile-home.php';
			}else
			{
				alert(data);
			}
		}
	})
})

$("#addDoc").click(function(e){

	$.ajax({

		url: "core/addDoc.php",
		method: "POST",
		data  : $("#docForm").serialize(),
		
		success: function(data){
			if(data == 1)
			{
				alert('All fields required');
			}else
			{
				alert("Success");
			$("#docForm").trigger('reset');
			window.location = 'admin-home.php';
			}
			
		}

	})
})
	 

$("#addAdmin").click(function(e){

	$.ajax({

		url: "core/addAdmin.php",
		method: "POST",
		data  : $("#admForm").serialize(),
		
		success: function(data){
			if(data == 1)
			{
				alert('All fields required');
			}else
			{
				alert("Success");
			$("#admForm").trigger('reset');
			window.location = 'admin-home.php';
			}
			
		}

	})
})

})

