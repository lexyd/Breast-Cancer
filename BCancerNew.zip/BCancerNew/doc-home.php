<?php include "core/handle.php";?>

<?php
if(isset($_SESSION['uid']))
{
	$user_id = $_SESSION['uid'];
	$userData = getUserData($con,$user_id, 'tbl_doc');
	$msgSql = mysqli_query($con,"SELECT tbl_patients.name AS name, tbl_msg.msg AS msg, tbl_msg.id AS uid  FROM tbl_msg,tbl_patients WHERE tbl_patients.id = tbl_msg.uid AND tbl_msg.status = 'S' ") or die(mysqli_error($con));
}
	
else
	header("Location: index.php");


?>


<link href="css/smart-forms.css" rel="stylesheet">
<?php include "incdoc-head.php";?>






<input type="hidden" name="glbuid" id="glbuid" value="<?php echo $userData['id'] ?>"> 



<!-- DIAGNOSIS CHECK TAB-->
<div class="tab-pane  fade in active" id="home-3">

	<div class="row">
		<table class="table  table-condensed">

		<tbody id="message-body">
			  <th class="text-center"></th>
			  <th class="text-center">Name </th>
			  <th class="text-center">Message</th>
			  <th class="text-center">Option</th>

			  
			  <?php $i=1; while( $rowmsg = mysqli_fetch_assoc($msgSql) ) {
			  ?>
			  	<tr>
			  	    <td class="text-center"><?php echo $i; ?></td>
			  		<td class="text-center"><?php echo $rowmsg['name'] ?></td>
			  		<td class="text-center"><?php echo $rowmsg['msg'] ?></td>
			  		<td class="text-center">
			  		    <a href="#" data-msgd="<?php echo $rowmsg['uid'] ?>"  class="reply"> Reply </a>
					</td>
			  	</tr>
			  	<?php $i++;   } ?>
		</tbody>
		</table>
	</div>

		<div class="row">
			<form id="repform1" class="ReplyForm" style="display: none" >
			<div class="col-md-8 col-md-offset-2">
			<input type="hidden" id="messageId" name="messageId">
			   <div class="form-group">
			   <label for="Message">Message</label>
				<textarea placeholder="Type your message here. Be brief and specific...." name="repmsgcontent" id="repmsgcontent" class="form-control" cols="5" rows="5"></textarea>
				</div>


				<div class="form-group">
				<label for="Submit"></label>
				<div class="col-md-6 col-md-offset-5"><button id="repmsg" class="g-btn">Reply</button></div>
			  </div>
			  </div>
			  </form>
		</div>
	</div>
		
</div>



<?php include "inc_pfooter.php";?>

