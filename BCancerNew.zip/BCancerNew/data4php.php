<?php
   /**
    * step 1: Include the `fusioncharts.php` file that contains functions to embed the charts.
    */
   include("core/fusioncharts.php");
?>
<html>

   <head>
    <title>FusionCharts XT - Simple Column 2D Chart</title>
    <!--
        Step 2:  Include the `fusioncharts.js` file. This file is needed to render the chart.
         Ensure that the path to this JS file is correct. Otherwise, it may lead to JavaScript errors.
    -->
    <script src="chart/fusioncharts.js"></script>
   </head>
   <body>
    <?php
        /**
         *  Step 3: Create a `columnChart` chart object using the FusionCharts PHP class constructor. 
         *  Syntax for the constructor: `FusionCharts("type of * chart", "unique chart id", "width of chart", 
         *  "height of chart", "div id to render the chart", "data format", "data source")`
         */
$uvals = 3;

$pos = $uvals * 12.5;
$neg = 100 - $pos;
$neu = $neg + 20;

// $pos = (int)$pos;
// $neg = (int)$neg;
// $neu = ()
        $columnChart = new FusionCharts("doughnut2D", "myFirstChart" , 450, 450, "chart-1", "json",
            '{
                "chart": {
                    "caption": "Testing this",
                    "subCaption": "Last year",
                "numberPrefix": "$",
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",
                "defaultCenterLabel": "Total revenue: $64.08K",
                "centerLabel": "Revenue from $label: $value",
                "centerLabelBold": "1",
                "showTooltip": "0",
                "decimals": "1",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                    "theme": "ocean"
                },
                "data": [
                        {"label": "Oct", "value": "'.$pos.'"},
                        {"label": "Nov", "value": "'.$neg.'"},
                        {"label": "Dec", "value": "'.$neu.'"}
                    ]
                }');
        /**
         *  Because we are using JSON/XML to specify chart data, `json` is passed as the value for the data
         *   format parameter of the constructor. The actual chart data, in string format, is passed as the value
         *   for the data source parameter of the constructor. Alternatively, you can store this string in a 
         *   variable and pass the variable to the constructor.
         */

        /**
         * Step 4: Render the chart
         */
        $columnChart->render();
    ?>
    <div id="chart-1"><!-- Fusion Charts will render here--></div>
    <?php echo $pos." ".$neg." ".$neu?>
   </body>
</html>