<?php include "core/handle.php";?>
<?php include "core/fusioncharts.php";?>
<?php include "inc_head.php";?>
<script src="js/template.js"></script>

<?php

$name = $_SESSION['bios']['name'];
$yes  = $_SESSION['bios']['yes'];
$no  = $_SESSION['bios']['no'];
$msg  = $_SESSION['bios']['msg'];

session_destroy();




$columnChart = new FusionCharts("doughnut2D", "myFirstChart" , 450, 450, "chart-1", "json",
            '{
                "chart": {
                    "caption": "Analysis of Mammogram Symptoms for '.ucfirst($name).'",
                    "subCaption": "Your risk of Breast Cancer in Percentage",
	                "paletteColors": "#f44336,#1aaf5d",
	                "bgColor": "#ffffff",
	                "showBorder": "0",
	                "use3DLighting": "0",
	                "showShadow": "0",
	                "enableSmartLabels": "0",
	                "startingAngle": "310",
	                "showLabels": "0",
	                "showPercentValues": "1",
	                "showLegend": "1",
	                "legendShadow": "0",
	                "legendBorderAlpha": "0",
	                "centerLabel": " $label: $value",
	                "centerLabelBold": "1",
	                "showTooltip": "0",
	                "decimals": "1",
	                "captionFontSize": "14",
	                "subcaptionFontSize": "14",
	                "subcaptionFontBold": "0",
	                 "theme": "ocean"
                },
                "data": [
                        {"label": "Cancer", "value": "'.$yes.'"},
                        {"label": "No Cancer", "value": "'.$no.'"}
                        
                    ]
                }');
        
 $columnChart->render();


?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div id="chart-1"></div>
		</div>
		<div class="col-md-6">
			<blockquote>
			  <p><?php echo $msg ?></p>
			</blockquote>
			<div><button onclick="print_window();" class="g-btn">Print</button><a href="profile-home.php#bio" class="btn">Back</a></div>
		</div>
	</div>
</div>


