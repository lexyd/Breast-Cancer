<!DOCTYPE html>
<html>

<head>
		<meta charset="utf-8">
		<title>Bcheck</title>
		<!-- Description, Keywords and Author -->
		<meta name="description" content="Your description">
		<meta name="keywords" content="Your,Keywords">
		<meta name="author" content="ResponsiveWebInc">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Styles -->
		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!-- Font awesome CSS -->
		<link href="css/font-awesome.min.css" rel="stylesheet">
		
		<!-- CSS for this page -->
		
		<!-- Base style -->
		<link href="css/styles/style.css" rel="stylesheet">
		<!-- Skin CSS -->
		<link href="css/styles/skin-lblue.css" rel="stylesheet" id="color_theme">
		
		<!-- Custom CSS. Type your CSS code in custom.css file -->
		<link href="css/custom.css" rel="stylesheet">
		<script src="js/jquery.js"></script>
		<script src="js/custom.js"></script>
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="#">
	</head>
	
	<body class="bg-img no-box">
				
		<!-- Login Starts  -->
		
		<div class="login-reg">