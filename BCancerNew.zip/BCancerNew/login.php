<?php include "inc_fhead.php";?>
<div class="login-reg-form">
			<!-- Heading -->
			<h4>Login to your Account</h4>
			<br />
			<!-- Form -->
			<form id="loginform" class="form-horizontal" role="form">
				<!-- Form Group -->
				<div class="form-group">
					<!-- Label -->
					<label for="user" class="col-sm-3 control-label">Email</label>
					<div class="col-sm-9">
						<!-- Input -->
					  <input type="text" name="email" id="email" class="form-control" id="email" placeholder="Enter Email">
					</div>
				</div>
				<div class="form-group">
					<label for="password" class="col-sm-3 control-label">Password</label>
					<div class="col-sm-9">
					  <input type="password" name="pass" class="form-control" id="pass" placeholder="Enter Password">
					</div>
				</div>
				<div class="form-group">
						<!-- Label -->
						<!-- to hold all the age groups for patients -->
						<label for="user" class="col-sm-3 control-label">User Type </label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="utype" name="utype">
								 <option value="">Select User Type </option>
								 <option value="Doctor">Doctor</option>
								 <option value="Admin">Admin</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>
				<div class="form-group">
					<div class="col-sm-offset-3 col-sm-9">
						<!-- Button -->
						<button id="login" type="submit" class="btn btn-red">Login</button>&nbsp;
						
					</div>
				</div>

				<div class="s-media">
				<!-- Button -->
				<a href="index.php" class="btn btn-blue"><i class="fa fa-home"></i> &nbsp; Back to Homepage</a>
				
			</div>
				
			</form>
			<br />
			<hr />
			
		</div>
		<?php include "inc_ffooter.php";?>