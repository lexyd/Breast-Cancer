
<?php include "inc_fhead.php";?>
<div class="login-reg-form">
				<!-- Heading -->
				<span id="regmsg"><h4>Register An Account</h4></span>
				<h5 style="color: red">  </h5>
				<br />
				<!-- Form -->
				<form id="register-form" class="form-horizontal" role="form">
					<!-- Form Group -->

				<span id="form-sect">
					<div class="form-group">
						<!-- Label -->
						<label for="user" class="col-sm-3 control-label">Email </label>
						<div class="col-sm-9">
							<!-- Input -->
						  <input type="text" name="email"  class="form-control" id="user" placeholder="Email Address">
						</div>
					</div>
					<div class="form-group">
						<!-- Label -->
						<label for="user" class="col-sm-3 control-label">Full Name </label>
						<div class="col-sm-9">
							<!-- Input -->
						  <input type="text" class="form-control"  name="fname" id="user" placeholder="Full Name">
						</div>
					</div>
					<div class="form-group">
						<!-- Label -->
						<!-- to hold all the age groups for patients -->
						<label for="user" class="col-sm-3 control-label">Age Group </label>
						<div class="col-sm-9">
						<label class="form-control">
							<select id="ageup" name="ageup">
								 <option value="">Select Age Group </option>
								 <option value="21-30">21-30</option>
								 <option value="31-40">31-40</option>
								 <option value="41-50">41-50</option>
								 <option value="51-60">51-60</option>
								 <option value="61-70">61-70</option>
							</select>
							<!-- <i class="arrow"></i> -->  
						</label>
						</div>
					</div>
					<div class="form-group">
						<!-- Label -->
						<label for="user" class="col-sm-3 control-label">Phone Number </label>
						<div class="col-sm-9">
							<!-- Input -->
						  <input type="text" name="phone"  class="form-control" id="phone" placeholder="Phone Number">
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Password</label>
						<div class="col-sm-9">
						  <input type="password" name="pass1"  class="form-control" id="pass1" placeholder="Password">
						</div>
					</div>

					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Re type Password</label>
						<div class="col-sm-9">
						  <input type="password" name="pass2"  class="form-control" id="pass2" placeholder="Password">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<!-- Button -->
							&nbsp;
							
						</div>
					</div>
				</span>

					<div class="s-media">
					<!-- Button -->
					<button id="register" class="btn btn-green">Register</button>
					<a id="profile" class="btn btn-blue"><i class="fa fa-home"></i> &nbsp; Back to Homepage</a>
					
				</div>
					
				</form>

				<br />
				<hr />
				
			</div>
<?php include "inc_ffooter.php";?>