<?php include "core/handle.php";?>

<?php

if(isset($_GET['id']))
{
	$did = $_GET['id'];
	$sql = mysqli_query($con,"DELETE FROM tbl_doc WHERE id =$did ");
}

if(isset($_GET['ad']))
{
	$did = $_GET['ad'];
	$sql = mysqli_query($con,"DELETE FROM tbl_admin WHERE id =$did ");
}



if(isset($_SESSION['uid']))
{
	$user_id = $_SESSION['uid'];
	$userData = getUserData($con,$user_id, 'tbl_admin');
	$sqlDoc = mysqli_query($con,"SELECT * FROM tbl_doc");
	$adminSql = mysqli_query($con,"SELECT * FROM tbl_admin");
}
	
else
	header("Location: index.php");


?>


<link href="css/smart-forms.css" rel="stylesheet">
<?php include "inc_adhead.php";?>






<input type="hidden" name="glbuid" id="glbuid" value="<?php echo $userData['id'] ?>"> 



<!-- DIAGNOSIS CHECK TAB-->
<div class="tab-pane  fade in active" id="home-3">

	<div class="row">
		<table class="table table-responsive table-condensed">
		<tbody>
		  <th class="text-center">SN</th>
		  <th class="text-center">Name </th>
		  <th class="text-center">Email</th>
		  <th class="text-center">Password</th>
		  <th class="text-center">Phone Number</th>
		  <th class="text-center">Option</th>

		  
		  <?php $i=1; while($rowDoc = mysqli_fetch_assoc($sqlDoc)) {
		  ?>
		  	<tr>
		  	    <td class="text-center"><?php echo $i; ?></td>
		  		<td class="text-center"><?php echo $rowDoc['name'] ?></td>
		  		<td class="text-center"><?php echo $rowDoc['email'] ?></td>
		  		<td class="text-center"><?php echo $rowDoc['pass'] ?></td>
		  		<td class="text-center"><?php echo $rowDoc['phone'] ?></td>
		  		<td class="text-center"><a href="admin-home.php?id=<?php echo $rowDoc['id'] ?>">Delete</a></td>
		  	</tr>
		  	<?php $i++;   } ?>
		  </tbody>
		</table>
	</div>

	<div class="row">

		<form id="docForm">
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Full Name</label>
			    <input type="text" name="dname"   class="form-control" required id="" placeholder="Full Name">
			  </div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Email Address </label>
			    <input type="text" name="demail"   class="form-control" required id="" placeholder="Full Name">
			  </div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Phone Number</label>
			    <input type="text" name="dphn"   class="form-control" required id="" placeholder="Phone Number">
			  </div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Password</label>
			    <input type="text" name="dpass"   class="form-control" required id="" placeholder="Password">
			  </div>
			</div>
		</form>
	</div>

	<div class="row">
		<div class="col-md-6 col-md-offset-5">
			<button id="addDoc" class="g-btn">Add</button>
		</div>
	</div>
			
</div>


<div class="tab-pane  fade in " id="admins">

	<div class="row">
		<table class="table table-responsive table-condensed">
		<tbody>
		  <th class="text-center">SN</th>
		  <th class="text-center">Admin </th>
		  <th class="text-center">Email</th>
		  <th class="text-center">Password</th>
		  <th class="text-center">Phone Number</th>
		  <th class="text-center">Option</th>

		  
		  <?php $i=1; while($rowadm = mysqli_fetch_assoc($adminSql)) {
		  ?>
		  	<tr>
		  	    <td class="text-center"><?php echo $i; ?></td>
		  		<td class="text-center"><?php echo $rowadm['name'] ?></td>
		  		<td class="text-center"><?php echo $rowadm['email'] ?></td>
		  		<td class="text-center"><?php echo $rowadm['pass'] ?></td>
		  		<td class="text-center"><?php echo $rowadm['phone'] ?></td>
		  		<td class="text-center"><a href="admin-home.php?ad=<?php echo $rowadm['id'] ?>">Delete</a></td>
		  	</tr>
		  	<?php $i++;   } ?>
		  </tbody>
		</table>
	</div>

	<div class="row">

		<form id="admForm">
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Full Name</label>
			    <input type="text" name="aname"   class="form-control" required id="" placeholder="Full Name">
			  </div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Email Address </label>
			    <input type="text" name="aemail"   class="form-control" required id="" placeholder="Full Name">
			  </div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Phone Number</label>
			    <input type="text" name="aphn"   class="form-control" required id="" placeholder="Phone Number">
			  </div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
			    <label for="exampleInputEmail1">Password</label>
			    <input type="text" name="apass"   class="form-control" required id="" placeholder="Password">
			  </div>
			</div>
		</form>
	</div>
	
	<div class="row">
		<div class="col-md-6 col-md-offset-5">
			<button id="addAdmin" class="g-btn">Add</button>
		</div>
	</div>
			
</div>


<?php include "inc_pfooter.php";?>

