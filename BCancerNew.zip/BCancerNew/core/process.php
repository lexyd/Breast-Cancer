<?php include "handle.php";?>
<?php include "fusioncharts.php";?>
<?php


if(isset($_POST['diagnose'])){

$pname = $_POST['pname'];
$message = '';

$uvals = count($_POST['s1']);

$pos = $uvals * 12.5;
$neg = 100 - $pos;

if($pos < 50)
{
	$message = '
	            From the analysis of your symptoms we 
	            observed that you have a low risk of 
	            breast cancer. We urge you  to still 
	            take a mammogram test';
}else
{
	$message = 'You have a high risk of breast cancer please take a Biospy test';
}

$_SESSION['cancer'] = array(
						'name'     => $pname,
						'positive' => $pos,
						'negative' => $neg,
						'message'  => $message
					    );
// $pos = (int)$pos;
// $neg = (int)$neg;
        echo 1;

}

?>