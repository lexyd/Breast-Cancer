<?php require_once "conn.php";?>
<?php require_once "handle.php";?>
<?php



$sql = mysqli_query($con,"SELECT *
						  FROM cause
						  WHERE status = 'Pending'
						  ");

$sql2 = mysqli_query($con, "SELECT *
							FROM tbl_acts
							ORDER BY id 
							DESC");

?>