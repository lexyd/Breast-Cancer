<?php
include "handle.php";

$tbl = '';
if(empty($_POST['utype']) || empty($_POST['email']) || empty($_POST['pass'])){

	echo "All fileds required";
	
}else
{

	$type = $_POST['utype'];

		switch ($type) {
			case 'Admin':
				$tbl = 'tbl_admin';
				break;
			case 'Patient':
				$tbl = 'tbl_patients';
				break;
			case 'Doctor':
				$tbl = 'tbl_doc';
				break;
			
			default:
				# code...
				break;
		}
//echo $tbl;
 
	$email = mysqli_real_escape_string($con,$_POST["email"]);
	$password = $_POST["pass"];
	$sql = "SELECT * FROM $tbl WHERE email = '$email' AND pass = '$password' ";
	$run_query = mysqli_query($con,$sql)or die(mysqli_error($con));
	$count = mysqli_num_rows($run_query);
	
	if($count == 1){
		$row = mysqli_fetch_assoc($run_query);
		$_SESSION["uid"] = $row["id"];
		// $_SESSION["type"] = $type;
		// $_SESSION["name"] = $row["name"];

		switch ($type) {
				case 'Admin':
					echo 1;
					break;
				case 'Patient':
					echo 2;
					break;
				case 'Doctor':
					echo 3;
					break;
				
				default:
					
					break;
			}			
	}else
	{
		echo "User not found please check your details properly ";

	}


}

		
		//echo 1;
?>