<?php
define('DB_NAME','bc_db');
define('DB_USER', 'root');
define('DB_PASSWORD','');
define('DB_HOST', 'localhost');
//define('DIR','index.php');

$con = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

if (!$con)
  {
  echo "We Are Experiencing Down Time Error";
  exit();
  }

?>

