<?php include "handle.php";?>
<?php


if(isset($_POST['diagnose']))
{
	$tot = $_POST['tot'];
	$cc  = $_POST['cc'];
	$not = $_POST['not'];
	$sot = $_POST['sot'];
	$name = $_POST['name'];

	$total = $tot + $cc + $not + $sot;

	$notTotal = 100 - $total;

	if($total < 50 )
	{
		$msg = 'You have a low risk of breast cancer we suggest you take the following preventive measures<br>
		         Exercise Regularly<br>
		         Avoid Stress<br>
		         Avoid Air Pollution<br>
		         Get Enough Sleep<br> ';
	}else
	{
		$msg = 'Please see the health specialist for immediate treatment ';
	}

	$_SESSION['bios'] = array(
				'name'   => $name,
				'yes'   => $total,
				'no' => $notTotal,
				'msg' => $msg
		);


	echo 1;
}


?>