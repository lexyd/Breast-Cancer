<?php
include "handle.php";

$name = $_POST['aname'];
$email = $_POST['aemail'];
$phn = $_POST['aphn'];
$pass = $_POST['apass'];

if(empty($name) || empty($email) || empty($phn) || empty($pass))
{
	echo 1;
}else
{
	mysqli_query($con,"INSERT INTO tbl_admin VALUES ('','$name','$email','$phn','$pass')");
	echo "Success";
}

?>