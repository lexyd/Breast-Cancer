<?php
include "handle.php";

$name = $_POST['dname'];
$email = $_POST['demail'];
$phn = $_POST['dphn'];
$pass = $_POST['dpass'];

if(empty($name) || empty($email) || empty($phn) || empty($pass))
{
	echo 1;
}else
{
	mysqli_query($con,"INSERT INTO tbl_doc VALUES ('','$name','$email','$phn','$pass')");
	echo "Success";
}







?>