<?php session_start(); ?>
<?php require_once "conn.php";?>
<?php include "inc_query.php";?>
<?php

//$currency = '&#x20A6;' ;

// function check_id($con,$id,$tbl)
// {
//     $id_sql = mysqli_query($con,"SELECT id FROM $tbl WHERE id = '$id' ")or die(mysqli_error($con));

//     $que = mysqli_num_rows($id_sql);

//      $rep = ($que == 1) ? 1 : 0;
        
//     return $rep;
// }


function word_teaser($string, $count){
  $original_string = $string;

  $words = explode(' ', $original_string);//explode breaks a string into an array

   if (count($words) > $count){
   $words = array_slice($words, 0, $count);//start slicing ($words) from the first word and return $count number of words
   $string = implode(' ', $words);
  }
 
  return $string;
}

function getUserData($con,$id,$tbl2)
{

  $result = array();
   $sql = mysqli_query($con,"SELECT * FROM $tbl2 WHERE id = '$id' " )or die(mysqli_error($con));
   $sqlData  = mysqli_fetch_array($sql);

   foreach ($sqlData as $key=>$value ) {
     $result[$key] = $value;
   }

   return $result;
}

// function getUserHistory($con,$id,$tbl2)
// {

//   $result = array();
//    $sql = mysqli_query($con,"SELECT * FROM $tbl2 WHERE uid = '$id' " )or die(mysqli_error($con));
//    $sqlData  = mysqli_fetch_array($sql);

//    foreach ($sqlData as $key=>$value ) {
//      $result[$key] = $value;
//    }

//    return $result;
// }





function arkiveUser($con,$uid,$symps,$styp,$tbl)
{
    mysqli_query($con,"INSERT INTO $tbl VALUES ('','$uid','$symps','$styp',CURRENT_TIME()) ")or die(mysqli_error($con));
}



?>

