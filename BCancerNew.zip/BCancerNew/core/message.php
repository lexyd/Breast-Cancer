<?php 
include "handle.php";


if(isset($_POST['msg']))
{
	if(empty($_POST['message'])){
		echo "Empty Message not allowed";
		exit();
	}else
	{
		$id = $_POST['id'];
		$msg = $_POST['message'];

		mysqli_query($con,"INSERT INTO tbl_msg (uid,msg,status,sdate) VALUES ('$id','$msg','S',CURRENT_TIME())")or die(mysqli_error($con));
		echo "Message sent";
	}
}


?>