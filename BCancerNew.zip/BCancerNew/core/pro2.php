<?php include "handle.php";?>
<?php

if(isset($_POST['diagnose']))
{
	$name = $_POST['name'];
	$test = $_POST['test'];
	$score= $_POST['score'];
	$msg = '';
	$cancer = '';
	$benign = '';
	$null  =  '';

	switch ($score) {
		case 0:
		    $null = 0;$benign=0;$cancer=0;
		    $msg  = 'A possible abnormality may not be seen clearly more tests like spot compression magnified views, special mammogram are recommended'; 
			# code...
			break;
		case 1:
			$null = 100;$benign=0;$cancer=0;
			$msg = 'There\'s no significant abnormality. the breast look the same with no masses(lumps), distorted structures,or suspicious calcifications';//Theres no significant abnormality. the breast look the same with no masses(lumps), distorted structures,or suspicious calcifications.
			break;
		case 2:
		    $null = 0; $benign=45; $cancer=0;
		    $msg  = 'No sign of Cancer but Benign calcifications could exist';
			# code...
			break;
		case 3:
			$null = 0; $benign=75; $cancer=5;
			$msg  = 'This result shows a very high chance of benign. Follow up this test with another within a short time frame (i.e 6months interval for 2 years)';
			# code...
			break;
		case 4:
		    $null = 0; $benign=50; $cancer=50;
		    $msg  = 'Suspicios abnormality. Findings do not definitely look like cancer but could be cancer. A BIOSPY is recommended ';
			# code...
			break;
		case 5:
			$null = 0; $benign=5; $cancer=95;
			$msg = 'The results look like cancer. BIOSPY is very strongly recommended.';
			# code...
			break;
		case 6:
			$null = 0; $benign=0; $cancer=100;
			$msg  = 'Cancer Detected. Take more mammogram tests and study the results';
			# code...
			break;
		
		default:
			# code...
			break;
	}


	$_SESSION['mamo'] = array(
				'name'   => $name,
				'null'   => $null,
				'benign' => $benign,
				'cancer' => $cancer,
				'test'   => $test,
				'msg'    => $msg
		);

	echo 1;
}

?>