<?php include "core/handle.php";?>
<?php include "core/fusioncharts.php";?>
<?php include "inc_head.php";?>
<script src="js/template.js"></script>

<?php

$name = $_SESSION['mamo']['name'];
$null  = $_SESSION['mamo']['null'];
$benign  = $_SESSION['mamo']['benign'];
$cancer  = $_SESSION['mamo']['cancer'];
$msg  = $_SESSION['mamo']['msg'];
$test  = $_SESSION['mamo']['test'];

session_destroy();




$columnChart = new FusionCharts("doughnut2D", "myFirstChart" , 450, 450, "chart-1", "json",
            '{
                "chart": {
                    "caption": "Analysis of Mammogram Symptoms for '.ucfirst($name).'",
                    "subCaption": "Your risk of Breast Cancer in Percentage",
	                "paletteColors": "#f44336,#1aaf5d,#000000",
	                "bgColor": "#ffffff",
	                "showBorder": "0",
	                "use3DLighting": "0",
	                "showShadow": "0",
	                "enableSmartLabels": "0",
	                "startingAngle": "310",
	                "showLabels": "0",
	                "showPercentValues": "1",
	                "showLegend": "1",
	                "legendShadow": "0",
	                "legendBorderAlpha": "0",
	                "centerLabel": "Risk of being $label: $value",
	                "centerLabelBold": "1",
	                "showTooltip": "0",
	                "decimals": "1",
	                "captionFontSize": "14",
	                "subcaptionFontSize": "14",
	                "subcaptionFontBold": "0",
	                 "theme": "ocean"
                },
                "data": [
                        {"label": "Cancer", "value": "'.$cancer.'"},
                        {"label": "Benign", "value": "'.$benign.'"},
                        {"label": "No Result", "value": "'.$null.'"}
                        
                    ]
                }');
        
 $columnChart->render();


?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div id="chart-1"></div>
		</div>
		<div class="col-md-6">
			<blockquote>
			  <p><?php echo $msg ?></p>
			</blockquote>
			<div><button onclick="print_window();" class="g-btn">Print</button><a href="profile-home.php" class="btn">Back</a></div>
		</div>
	</div>
</div>


