-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2017 at 12:18 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phn` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `ageg` varchar(100) DEFAULT NULL,
  `join_d` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `name`, `email`, `pass`, `phone`) VALUES
(1, 'Akinyosoye Yetunde Elizabeth', 'yetunde@gmail.com', 'easytoremember', '2222222222'),
(2, 'Udoh Utibe Bassey', 'udoh@gmail.com', 'easytoremember', 'dansuki');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doc`
--

CREATE TABLE IF NOT EXISTS `tbl_doc` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_doc`
--

INSERT INTO `tbl_doc` (`id`, `name`, `email`, `pass`, `phone`) VALUES
(4, 'Ernest Olurin', 'ernest@gmail.com', 'easytoremember', '0904642739'),
(5, NULL, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patients`
--

CREATE TABLE IF NOT EXISTS `tbl_patients` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phn` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `ageg` varchar(100) DEFAULT NULL,
  `join_d` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_patients`
--

INSERT INTO `tbl_patients` (`id`, `name`, `email`, `phn`, `pass`, `ageg`, `join_d`) VALUES
(10, 'Oladapo Raheem', 'dapo@gmail.com', '07069494803', 'dapo', '31-40', '2017-02-22 14:01:16'),
(12, 'bisi lola', 'bisi@gmail.com', '07069494802', 'bisi', '31-40', '2017-02-23 14:21:33'),
(13, 'keshin ro', 'keshin@gmail.com', '99999999999', 'keshin', '41-50', '2017-02-23 14:26:49'),
(14, 'tundewooo', 'tunde@gmail.com', '09090909090', 'tunde', '21-30', '2017-02-23 14:28:44'),
(15, 'jwngo', 'owfnojq1', '22212222222', 'gugu', '31-40', '2017-02-23 14:29:49'),
(16, 'jdbi', 'hvuvuu', '74747474747', 'fefe', '31-40', '2017-02-23 14:32:47'),
(17, 'hepzybha', 'hepzy', '88883344567', 'hep', '21-30', '2017-02-23 14:34:00'),
(18, 'IJSDBGIABFI', 'dapo', '72727272727', 'GH', '21-30', '2017-02-23 14:35:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_doc`
--
ALTER TABLE `tbl_doc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_patients`
--
ALTER TABLE `tbl_patients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_doc`
--
ALTER TABLE `tbl_doc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_patients`
--
ALTER TABLE `tbl_patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
